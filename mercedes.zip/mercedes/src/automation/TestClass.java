package automation;


import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.SearchContext;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import java.io.File;
import java.io.IOException;
import java.time.Duration;
import java.util.List;
import org.apache.commons.io.FileUtils;

public class TestClass {
	public static void main(String[] args) throws InterruptedException, IOException {

		
		WebDriver chromedriver = new ChromeDriver();

		chromedriver.get("https://www.mercedes-benz.co.uk");

		chromedriver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		WebDriverWait wait = new WebDriverWait(chromedriver, Duration.ofSeconds(20));


		/*Accept Cookies*/		
		WebElement cookiesBanner = chromedriver.findElement(By.xpath("//*[@settings-id='fph8XBqir']"));

		SearchContext cookiesShadowRoot = cookiesBanner.getShadowRoot();

		WebElement acceptAllCookiesButton = cookiesShadowRoot.findElement(By.className("button--accept-all"));

		wait.until(ExpectedConditions.visibilityOf(acceptAllCookiesButton));
		wait.until(ExpectedConditions.elementToBeClickable(acceptAllCookiesButton));
		acceptAllCookiesButton.click();
		

		/*Click menu button*/		
		WebElement header = chromedriver.findElement(By.xpath("//*[@component-id='738cae9548fd09b2721cad874b486cf2']"));

		SearchContext headerShadowRoot = header.getShadowRoot();

		WebElement menuButton = headerShadowRoot.findElement(By.className("owc-header__item-menu"));
		menuButton.click();
	
		
		/*Click our models button*/	
		WebElement ourModelsButton= headerShadowRoot.findElement(By.className("owc-header-navigation-topic__button"));
		ourModelsButton.click();

		/*Click Hatchbacks*/	
		WebElement hatchbackHost = chromedriver.findElement(By.xpath("//*[@component-id='d90117080adce2a4477e5c8c6a29d632']"));
		SearchContext hatchbackShadowRoot = hatchbackHost.getShadowRoot();

		Thread.sleep(Duration.ofSeconds(5));		
		WebElement hatchbacksButton = hatchbackShadowRoot.findElement(By.name("sportstourer"));

		wait.until(ExpectedConditions.visibilityOf(hatchbacksButton));
		wait.until(ExpectedConditions.elementToBeClickable(hatchbacksButton));
		hatchbacksButton.click();

		/*Click A-Class Hatchback*/	
		List<WebElement> list = hatchbackShadowRoot.findElements(By.className("_flyout-group-item_ggfyq_47"));
		for(WebElement el : list) {
			if(el.getText().toString().equals("A-Class Hatchback")) {
				el.click();
				break;
			}
		}

		/*Click Build your car*/	
		WebElement buildCarHeader = chromedriver.findElement(By.xpath("//*[@component-id='cea4a4a51557a29073a51c4f3fc4d9e3']"));
		SearchContext buildCarHeaderHeaderShadowRoot = buildCarHeader.getShadowRoot();		

		List<WebElement> list2 = buildCarHeaderHeaderShadowRoot.findElements(By.className("owc-stage-cta-buttons__button"));
		for(WebElement el : list2) {
			if(el.getText().toString().equals("Build your car")) {
				el.click();
				break;
			}

		}

		/*Click Fuel Type*/	
		WebElement fuelTypeHost = chromedriver.findElement(By.xpath("//*[@data-component-name='owcc-car-configurator']"));
		SearchContext fuelTypeShadowRoot = fuelTypeHost.getShadowRoot();
		WebElement fuelTypeButton = fuelTypeShadowRoot.findElement(By.className("cc-motorization-filters-primary-filters"));
		Thread.sleep(Duration.ofSeconds(5));
		fuelTypeButton.click();


		TakesScreenshot scrShot =((TakesScreenshot)chromedriver);     
		File SrcFile=scrShot.getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(SrcFile, new File("screenshot.png"));
		

		chromedriver.quit();
	}
}